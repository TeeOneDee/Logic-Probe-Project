/*
 * File:   main.c
 * Author: Tom Dunn
 * ALL RIGHTS RESERVED, INCLUDING, BUT NOT LIMITED TO, COPY, SLOGAN MARK AND TRADE MARK RIGHTS
 * Created on June 21, 2018, 2:18 PM
 * Version: 1.00
 */

/*                                               "A LEVEL PLAYING FIELD"
 * It is the purpose of this project to implement a Microchip PIC12F683 controller as a dual level (CMOS and TTL,)
 * tri-state (low, non-determinate and high,) logic probe.
 * 
 * The logic level desired is selected via the tactile button switch. A button press toggles the selected Logic Level state between
 * CMOS and TTL. A LED code is blinked to verify the logic level that was selected. 
 * 
 * The measured level state is displayed via three, different colored LEDs.
 * 
 * CMOS calculations are based on the industry standard:
 * Probed DUT Logic Pin is < (1/3) DUT logic voltage reference level = Low State
 * Probed DUT Logic Pin is (>= 1/3 - <= 2/3) DUT logic voltage reference level = Indeterminate State
 * Probed DUT Logic Pin is > (2/3) DUT logic voltage reference level = High State
 * 
 * TTL calculations are based on the industry standard:
 * Probed DUT Logic Pin is < 0.80 volt = Low State
 * Probed DUT Logic Pin is >= 0.80 volts and <= 2.0 volts = Indeterminate State
 * Probed DUT Logic Pin is > 2.0 volts = High State
 */


// Includes and Header Files
#include <xc.h>
#include <stdlib.h>

// Definitions
#define LED_ON 1 // To be able to address an LED illumination state as text
#define LED_OFF 0 // To be able to address an LED illumination state as text
#define LED_LOW_PIN GP2 // To be able to address a low logic voltage LED state as text
#define LED_MID_PIN GP1 // To be able to address an indeterminate logic voltage LED state as text
#define LED_HIGH_PIN GP0 // To be able to address a high logic voltage LED state as text
#define BTN_PIN GP3 // To be able to address the button state as text
#define PROBE_RATIO 9.97 // probe resistor divider ratio (use float in #define)
#define ADC_MAX ((1 << 10) - 1) // 10-bit ADC maximum value + 1 = 0x03ff + 1 = 1024
#define _XTAL_FREQ 8000000 // Internal Crystal Oscillator Frequency setting
#define TTL_MODE 0 // To be able to address a TTL logic condition as text
#define CMOS_MODE 1 // To be able to address a CMOS logic condition as text
#define TIMER_CNT_1SEC 36 // Fosc = 8MHz / 4 = 2MHz  16-bit timer gives one interrupt every 65536 Fosc cycles
// Interrupts in 1 second = 2MHz / 65536 = approximately 36 interrupts
#define ADC_VREF 5.0	// ADC voltage reference is Vcc; modify if changed

// Global Variables
/*
 * The following vRefXxx values are defined below to allow the compiler to do
 * the math using ADC_MAX, ADC_REF, and PROBE_RATIO values from above.  Note that
 * floating point math is used but performed by the compiler and, thus, floating
 * point run-time libraries are not used.
 */
// Cutoff for low voltage in ADC bit value; default to TTL value; code updates with CMOS value if selected
unsigned int vRefLow = (unsigned int) ((0.8 * ADC_MAX) / (ADC_VREF * PROBE_RATIO));
// Cutoff for high voltage in ADC bit value; default to TTL value; code updates with CMOS value if selected
unsigned int vRefHigh = (unsigned int) ((2.0 * ADC_MAX) / (ADC_VREF * PROBE_RATIO));
// One volt ADC value used in CMOS reference voltage selection
unsigned int vRef1V = (unsigned int) ((1.0 * ADC_MAX) / (ADC_VREF * PROBE_RATIO));

// Function Declarations 
void initPIC(void); // Initialize PIC state
unsigned int readADC(void); // Read 10-Bit ADC result
void updateLEDs(unsigned int adcValue); // To reset LEDs.
unsigned char getOpMode(void); // For get operating mode.
void confirmTTL(void); // TTL logic selection blink confirmation
void confirmCMOS(void); // CMOS logic selection blink confirmation
void getCmosVref(void); // Capture the CMOS voltage reference
void confirmCmosVref(void); // CMOS voltage reference blink confirmation

/* 
 * program entry point
 */
void main(void) {
    unsigned int uintTemp; // Temporary storage to be used to pass the readADC value
    unsigned char selectedMode; // Storage for selected logic type
    initPIC(); // Call the function that includes the needed initial PIC configurations
    selectedMode = getOpMode(); // Call getOpMode function and assign the logic type selection to variable
    if (selectedMode == TTL_MODE) confirmTTL(); // If logic type is TTL, blink TTL confirmation
    if (selectedMode == CMOS_MODE) confirmCMOS(); // If logic type is CMOS, blink CMOS confirmation
    if (selectedMode == CMOS_MODE) getCmosVref(); // If CMOS logic type has been selected, get the voltage reference value

    while (1) {
        /* 
         * Within the main loop:
         */
        uintTemp = readADC(); // Call readADC function and assign ADC value to uintTemp.
        updateLEDs(uintTemp); // Call updateLEDs function, using uintTemp, as substituted argument, as adcVal and
        // uintTemp are the same type.
    }
}

/*
 * Initialize PIC state, i.e., GPIOs, oscillators, ADC, etc.
 */
void initPIC(void) {
    // Pin Configurations
    TRISIObits.TRISIO0 = 0; // Sets Pin 7/GP0 as output, for blue (logic low) LED
    TRISIObits.TRISIO1 = 0; // Sets Pin 6/GP1 as output, for yellow (logic non-determinate) LED
    TRISIObits.TRISIO2 = 0; // Sets Pin 5/GP2 as output, for red (logic high) LED    
    TRISIObits.TRISIO3 = 1; // Sets Pin 4/GP3 as input, for Switch input
    TRISIObits.TRISIO4 = 1; // Sets Pin 3/AN3 as an input, for Probe input.
    TRISIObits.TRISIO5 = 0; // Sets unused Pin 2 as output, to terminate
    CMCON0 = 0b00000111; // Disable all comparators

    ANSEL = 0b01011000; /*
    ANSELbits ANS0 through ANS3 default to analog when TRIS0bits set for input
    per Register 4 - 3 in DS. Should probably set others to 0 (digital). (Odd... seems like the default would be 0.)
    ANSELbits.ANS3 = 1; // Sets Pin 3/AN3 as analog, for Probe input.
    ANSELbits.ADCS = 0b101; // = ADC Clock Period = 2.0uS */

    GP5 = 0; // Per Microchip recommendations: Sets unused Pin 2 state to low, to terminate unused pin.
    // Hardware Warning: Either leave pin unconnected or add resistor to gnd. See data sheet.

    // Oscillator Configurations
    OPTION_REG = 0B10001000; // GPIO Pull Up Disabled, Interrupt Edge Falling, Clock Source Internal,
    // Timer0 Source Edge L/H, Prescaler assigned to WDT to cause Timer1 Prescaler Rate to be 1:1
    OSCCONbits.IRCF = 0b111; // Sets Internal Oscillator Frequency to 8MHz

    // Use Timer1, for 16 bit register.
    T1CON = 0b00000000;
    /*	7 - Timer1 Gate Invert Bit = 0
     *	6 - Timer1 Gate Enable Bit = 0
     *	5 - Timer1 Input Clock Prescaler = 0 for 1:1  1 of 2
     *	4 - Timer1 Input Clock Prescaler = 0 for  1:1  2 of 2
     *	3 - LP Oscillator Enable = 0 // Not Used
     *	2 - Timer1 External Clock Input Synchronization = 0 // Not Used
     *	1 - Timer1 Clock Source = 0 // Internal (FOSC/4)
     *	0 - Timer1 On Bit = 0 // Timer Disabled On Start (TMR1ON) */

    // ADC Configurations 
    ADCON0 = 0b10001101;
    //ADCON0bits.ADFM = 1;  // Sets right justification of ADC Conversion Results
    //ADCON0bits.VCFG = 0;  // The voltage reference source will be from Vdd.
    // Not Used = 0
    // Not Used = 0
    //ADCON0bits.CHS = 11;  // Selects AN3/Probe for ADC       
    // ADCON0bits. Go/Done = 0;
    //ADCON0bits.ADON = 1;  // Turns on ADC Function

    // Clear the TMR1H:TMR1L register pair and TMR1IF, before enabling interrupts
    TMR1H = 0B00000000;
    TMR1L = 0B00000000;
    TMR1IF = 0;

    // Clear/Turn off all LEDs
    LED_LOW_PIN = LED_OFF;
    LED_MID_PIN = LED_OFF;
    LED_HIGH_PIN = LED_OFF;
}

/*
 * Read instantaneous ADC value (not averaged).  Returns the 10-bit value as
 * an unsigned 16-bit integer.  Note that this value could safely be returned
 * as a signed integer since it would always be positive (the high 6 bits are 
 * always cleared).
 */
unsigned int readADC(void) { // Define the function that gets the instantaneous ADC value (not averaged)
    unsigned int adcRet; // Storage for ADC return value
    ADCON0bits.GO_DONE = 1; // Start ADC Conversion
    while (ADCON0bits.GO_DONE); // Wait for ADC conversion to complete. Do nothing
    // Read the ADRES registers and returns their values to adcRet
    adcRet = (unsigned int) (ADRESH << 8) | ADRESL; // Read the readADC 10 bit result
    return adcRet; // Return value to caller                                                                                    
}

/*
 * Update LEDs to reflect current probe voltage logic state for selected 
 * TTL/CMOS mode.  Current ADC value must be read and passed by caller.
 */
void updateLEDs(unsigned int adcValue) {
    // Turn off all LEDs
    LED_LOW_PIN = LED_OFF;
    LED_MID_PIN = LED_OFF;
    LED_HIGH_PIN = LED_OFF;

    // Compare the passed adcValue to vRefLow and vRefHigh and turn on the appropriate LED
    if (adcValue < vRefLow) { // Test for low logic state
        LED_LOW_PIN = LED_ON; // Display blue, for low
    } else if (adcValue > vRefHigh) { //  Test for high logic state
        LED_HIGH_PIN = LED_ON; // Display red, for high
    } else { // Otherwise, the logic state is indeterminate
        LED_MID_PIN = LED_ON; // Display yellow, for indeterminate
    }
}

/*
 * Get user selection of TTL or CMOS logic levels.  If user presses the button
 * before the time-out, returns CMOS_MODE.  Otherwise returns TTL_MODE.  During
 * the selection period, flashes LED(s) in a "selection mode pattern."
 * Confirm TTL type selected = 5 quick blue flashes
 * Confirm CMOS type selected = 5 quick red flashes
 * Confirm that CMOS type selection is waiting for the probe to be applied to the voltage reference pin = continuous quick
 * yellow flashes 
 * Confirm CMOS voltage reference has been captured = 1 red, three-second blink
 */
unsigned char getOpMode(void) { // Function to get logic type for operating mode.
    unsigned int ledCnt = TIMER_CNT_1SEC / 2; // TIMER_CNT_1SEC * 5;  Logic type selection period is 5 seconds.
    // 36 / sec x 5 seconds = 180. LED flash on period is � second. (36)/2 = 18. 
    unsigned int timerCnt = TIMER_CNT_1SEC * 8; // Storage to count time. The logic type selection defaults to TTL 
    // at eight seconds

    LED_MID_PIN = LED_ON;
    // getOpMode Function
    TMR1ON = 1; // Start Timer1
    do { // Get Logic Type selection
        if (BTN_PIN == 0) { // Test for button press.
            return CMOS_MODE; // Return value to caller.
        }
        // If button was not pressed.
        if (TMR1IF == 0) continue; // If timer flag is not set
        timerCnt--; // Decrement timerCnt
        ledCnt--; // Decrement ledCnt
        TMR1IF = 0; // Clear timer flag
        // Blink yellow, during logic type selection period.
        if (ledCnt != 0) continue; // When one-half second has passed
        ledCnt = TIMER_CNT_1SEC / 2; // Assigns ledCnt a value of one-half second
        LED_MID_PIN ^= 1; // Toggle yellow LED
    } while (timerCnt > 0); // Loop, as long as timerCnt is greater than zero.
    return TTL_MODE; // Return value to caller.
}

// Confirm selected logic type

void confirmTTL(void) { // If selected logic type is TTL
    LED_MID_PIN = LED_OFF; // Clear the yellow LED
    unsigned char count; // Storage for counting
    for (count = 0; count < 5; count++) { // Blink blue LED
        LED_LOW_PIN = LED_ON;
        __delay_ms(250);
        LED_LOW_PIN = LED_OFF;
        __delay_ms(250);
    }
    LED_LOW_PIN = LED_OFF; // Clear the blue LED
}

void confirmCMOS(void) { // If selected logic type is CMOS
    LED_MID_PIN = LED_OFF; // Clear the yellow LED
    unsigned char count; // Storage for counting
    for (count = 0; count < 5; count++) { // Blink red LED
        LED_HIGH_PIN = LED_ON;
        __delay_ms(250);
        LED_HIGH_PIN = LED_OFF;
        __delay_ms(250);
    }
    LED_HIGH_PIN = LED_OFF; // Clear the red LED
}

/*
 * Captures and stores the CMOS voltage reference for CMOS-mode operation.
 * Waits indefinitely for a voltage > a threshold voltage (currently 1V) on the 
 * probe tip.  Once a voltage > the threshold voltage is detected, the vRefLow 
 * and vRefHigh variables are set to 1/3 and 2/3 of the captured value.  Until 
 * the value is captured, LED(s) are flashed in a "capture CMOS reference voltage
 * pattern."
 */
void getCmosVref(void) { // CMOS Reference Voltage Function
    unsigned int timerCnt = TIMER_CNT_1SEC; // Timer Count will loop, until CMOS Voltage Reference is captured
    unsigned char ledCnt = TIMER_CNT_1SEC / 4; // Faster one-quarter second blink pattern, to distinguish from
    // logic type selection procedure.
    unsigned int adcCurr = 0; // Storage for current voltage reference
    do {
        adcCurr = readADC(); // Get current probe reading and assign it to adcCurr
        if (adcCurr > vRef1V) break; // probe voltage > 1V exits loop
        if (TMR1IF == 0) continue; // Poll Timer1 Interrupt Flag to see if it is set 
        timerCnt--; // Decrement timerCnt
        ledCnt--; // Decrement ledCnt
        TMR1IF = 0; // Clear Timer1 Interrupt Flag
        if (ledCnt > 0) continue; // Test ledCnt for additional remaining time
        // Toggle LED procedure
        LED_MID_PIN ^= 1; // Toggle yellow LED
        ledCnt = TIMER_CNT_1SEC / 4; // Set ledCnt time to one-quarter of a second
    } while (timerCnt > 0); // Loop until the CMOS reference voltage has been captured
    vRefLow = (unsigned int) adcCurr / 3; // Set the CMOS low logic state at one-third.
    vRefHigh = (unsigned int) (adcCurr * 2) / 3; // Set the CMOS high logic state at two-thirds. Note that parentheses are used
    // to force the proper mathematical evaluation order
    confirmCmosVref(); // As the CMOS voltage reference value has been captured, blink confirmation
}

void confirmCmosVref(void) { // If the CMOS voltage reference has been captured
    LED_MID_PIN = LED_OFF; // Clear the yellow LED
    LED_HIGH_PIN = LED_ON; // Display red LED
    __delay_ms(3000); // For three seconds
    LED_HIGH_PIN = LED_OFF; // Clear the red LED
}
